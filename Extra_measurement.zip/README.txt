README

exp1_028-039 	--> 	LVDT measurement with different inputs
		 	(Input parameters are written in private notes) 
sys_ident28-39 	--> 	Matlab file to identify the system, some 
			of them contain compare function to validate
		   	the model result
est_tf.mat 	--> 	exp1_028 tf model with sine input
est_tf_step.mat -->	exp1_032 tf model with sine input
